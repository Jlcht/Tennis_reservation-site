<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>
<h2>Supprimer un court</h2>

<body>
<form method="post" action="../controller/court_delete_c.php">
    <p>Veuillez indiquer le court à supprimer </p>
    <label for="court">court :</label>
    <select name="court" id="court">
        <?php
        session_start();
        $club = $_SESSION["club"];
        $db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
        $req = $db->prepare("SELECT court_de_tennis.id_court ,court_de_tennis.nom FROM court_de_tennis WHERE court_de_tennis.club_organisateur = ? ;");
        $req->execute([$club]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_court]'>$row[nom]</option>";
        }
        ?>
    </select>
    <br />
    <input type="submit" value="Supprimer">
</form>
</body>
</html>
