<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
    <style>
        form {
            width: 375px;
        }
    </style>
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>
<h2>Bloquer un court</h2>

<form method="post" action="../controller/court_locking_c.php">
    <p>Veuillez indiquer le court ainsi que le nouveau statut</p>
    <label for="court">Court :</label>
    <select name="court" id="court">
        <?php
        session_start();
        $club = $_SESSION["club"];
        $db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
        $req = $db->prepare("SELECT court_de_tennis.id_court ,court_de_tennis.nom FROM court_de_tennis WHERE court_de_tennis.club_organisateur = ? ;");
        $req->execute([$club]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_court]'>$row[nom]</option>";
        }
        ?>
    </select>
    <br />
    <label for="statut">Nouveau statut :</label>
    <select name="statut" id="statut">
        <option value="Disponible">Disponible</option>
        <option value="Bloque">Bloqué</option>
    </select>
    <br />
    <input type="submit" value="Modifier">
</form>

<p><a href="admin.php">Retour</a></p>
</body>
</html>

