<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Book-Tennis</title>

    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>
<nav>
    <ul>
        <li><a href="../controller/signout.php">Se déconnecter</a></li>
        <li><a href="account.php">Changer de club</a></li>
    </ul>

</nav>


<h2>Espace club : adhérant</h2>
<body>
<?php session_start() ;
$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
$req = $db->prepare("SELECT nom_club FROM club_de_tennis WHERE id_club = ?;");
$req->execute([$_SESSION['club']]);
$resultat = $req->fetch();
?>
<h3>Bonjour <?php echo $_SESSION['Email'] ?>, bienvenue dans l'espace du club <?php echo $resultat[0] ?>.</h3>

<table border="1">
    <tr>
        <th><a href="reservation_court.php">Reserver ou consulter un court</a></th>
    </tr>
    <tr>
        <th><a href="admin.php">Retour</a></th>
    </tr>
</table>
</body>
</html>