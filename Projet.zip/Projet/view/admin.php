<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Book-Tennis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<h2>Espace club : administrateur</h2>
<body>
<?php session_start() ;
$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
$req = $db->prepare("SELECT nom_club FROM club_de_tennis WHERE id_club = ?;");
$req->execute([$_SESSION['club']]);
$resultat = $req->fetch();
?>
<h3>Bonjour <?php echo $_SESSION['Email'] ?>, bienvenue dans l'espace du club <?php echo $resultat[0] ?>.</h3>

<table class="table">
    <tr>
        <th><a href="../view/court_management_i.php">Gérer les courts</a></th>
    </tr>
    <tr>
        <th><a href="../view/reservation_cancelling_i.php">Annuler une réservation</a></th>
    </tr>
    <tr>
        <th><a href="../view/court_locking_i.php">Bloquer un court</a></th>
    </tr>
    <tr>
        <th><a href="../view/add_adherant_i.php">Ajouter un adhérant</a></th>
    </tr>
    <tr>
        <th><a href="../view/expel_adherant_i.php">Expulser un adhérant</a></th>
    </tr>
    <tr>
        <th><a href="../view/statistics_i.php">Statistiques du club</a></th>
    </tr>
    <tr>
        <th><a href="../controller/signout.php">Se déconnecter</a></th>
    </tr>
    <tr>
        <th><a href="../view/account.php">Changer de club</a></th>
    </tr>
</table>

</body>
</html>