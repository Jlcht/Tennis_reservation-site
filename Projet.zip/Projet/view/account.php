<html>
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-Tenis</h1>
</header>
<nav>
    <ul>
        <li><a href="../controller/signout.php">Se déconnecter</a></li>
        <li><a href="../view/change_password.php">Changer son mot de passe</a></li>
    </ul>
</nav>
<h2>Accueil</h2>
<?php
session_start();

if(isset($_SESSION["Email"]))
{
    $email = $_SESSION["Email"];
    echo "<h3>Bonjour $email</h3>";
    ?>
    <form method="post" action="../controller/account_admin.php">

        <br />
        <label for="club">Choisir un club (connexion administrateur):</label>
        <select name="club" id="club">
            <?php
            $db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
            $req = $db->prepare("SELECT club_de_tennis.id_club, club_de_tennis.nom_club from club_de_tennis INNER JOIN membre_club ON membre_club.id_club = club_de_tennis.id_club INNER JOIN utilisateur ON utilisateur.id_utilisateur = membre_club.id_utilisateur WHERE utilisateur.email = ? AND membre_club.statut = 1;");
            $req->execute([$email]);
            $results = $req->fetchAll();
            foreach ($results as $row)
            {
                echo "<option value='$row[id_club]'>$row[nom_club]</option>";
            }
            ?>
        </select>
        <br />
        <input type="submit" value="Selectionner">
    </form>
    <br />
    <br />

    <form method="post" action="../controller/account_adherant.php">

        <br />
        <label for="club">Choisir un club(connexion adhérant):</label>
        <select name="club" id="club">
            <?php
            $db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
            $req = $db->prepare("SELECT club_de_tennis.id_club, club_de_tennis.nom_club from club_de_tennis INNER JOIN membre_club ON membre_club.id_club = club_de_tennis.id_club INNER JOIN utilisateur ON utilisateur.id_utilisateur = membre_club.id_utilisateur WHERE utilisateur.email = ?;");
            $req->execute([$email]);
            $results = $req->fetchAll();
            foreach ($results as $row)
            {
                echo "<option value='$row[id_club]'>$row[nom_club]</option>";
            }
            ?>
        </select>
        <br />
        <input type="submit" value="Selectionner">
    </form>
    <?php
}
?>

</body>
</html>