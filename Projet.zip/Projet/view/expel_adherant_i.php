<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>

<h2>Expulsion d'un adhérent</h2>


<form method="post" action="../controller/expel_adherant_c.php">
    <label for="court">Veuillez indiquer l'adhérant à expulser </label>
    <select name="id" id="id">
        <?php
        session_start();
        $club = $_SESSION["club"];
        $db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
        $req = $db->prepare("SELECT membre_club.id_utilisateur , email FROM membre_club INNER JOIN utilisateur ON membre_club.id_utilisateur = utilisateur.id_utilisateur WHERE id_club= ? AND membre_club.statut = 0 ;");
        $req->execute([$club]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_utilisateur]'>$row[email]</option>";
        }
        ?>
    </select>
    <br />
    <input type="submit" value="Expulser">
</form>

<p class ="center"><a class = "button" admin.php">Retour</a></p>

</body>
</html>