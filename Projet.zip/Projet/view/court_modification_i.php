<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
    <style>
        form {
            width: 650px;
        }
    </style>
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>
<h2>Modification d'un court</h2>

<form method="post" action="../controller/court_modification_c.php">
    <p>Indiquer le court a modifier</p>
    <label for="court">court :</label>
    <select name="court" id="court">
        <?php
        session_start();
        $club = $_SESSION["club"];
        $db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
        $req = $db->prepare("SELECT court_de_tennis.id_court ,court_de_tennis.nom FROM court_de_tennis WHERE court_de_tennis.club_organisateur = ? ;");
        $req->execute([$club]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_court]'>$row[nom]</option>";
        }
        ?>
    </select>
    <br />
    <br />
    <p>Information du court a modifier : </p>

    <label>
        Nom : <input type="text" name="name" />
    </label>

    <br />

    <label for="surface">surface :</label>
    <select name="surface" id="surface">
        <?php
        $db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
        $req = $db->prepare("SELECT surface.id_surface, surface.nom_surface from surface;");
        $req->execute([]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_surface]'>$row[nom_surface]</option>";
        }
        ?>
    </select>
    <br />
    <label for="emplacement">Emplacement :</label>
    <select name="emplacement" id="emplacement">
        <?php
        $req = $db->prepare("SELECT emplacement.id_emplacement, emplacement.nom_emplacement from emplacement;");
        $req->execute([]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_emplacement]'>$row[nom_emplacement]</option>";
        }
        ?>
    </select>

    <br />
    <input type="submit" value="Modifier">
</form>
</body>
</html>