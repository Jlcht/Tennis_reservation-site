<!DOCTYPE html>
<html lang="fr" >
<head>
    <meta charset="UTF-8">
    <title>Book-Tennis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tennis" />
    <h1>Book-Tenis</h1>
</header>
<h2>Réserver un court</h2>
<p>
    <?php session_start();
    $db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
    $email=$_SESSION["Email"];
    $club = $_SESSION["club"];
    echo "<h3>Bonjour $email</h3>";
    ?>
</p>

<form method="POST" action="../controller/reservation_court_con.php">
    <label>Id du court:</label>
    <input type="number" name="id_court" min="1" required>
    <br><br>
    <label>Date</label>
    <input type="date" name="date" min="<?php echo date('Y-m-d'); ?>">
    <br><br>
    <label>Heure</label>
    <select name="time" id="time">
        <option value="08:00">08:00</option>
        <option value="10:00">10:00</option>
        <option value="12:00">12:00</option>
        <option value="14:00">14:00</option>
        <option value="16:00">16:00</option>
        <option value="18:00">18:00</option>
        </select>
    <br><br>
    <label>Durée de la session</label>
        <select name="duree" id="duree">
            <option value="02:00">02:00</option>
        </select>
    <br><br>
    <label>Id du partenaire 1:</label>
    <select name="id_p1" id="id_p1">
        <?php
        $req = $db->prepare("SELECT membre_club.id_utilisateur , email FROM membre_club INNER JOIN utilisateur ON membre_club.id_utilisateur = utilisateur.id_utilisateur WHERE id_club= ? ;");
        $req->execute([$club]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_utilisateur]'>$row[email]</option>";
        }
        echo "<option value=1>Invité</option>";
        echo "<option value=2>Aucun</option>";
        ?>
    </select>
    <br><br>
    <label>Id du partenaire 2:</label>
    <select name="id_p2" id="id_p2">
        <?php
        $req = $db->prepare("SELECT DISTINCT membre_club.id_utilisateur , email FROM membre_club INNER JOIN utilisateur ON membre_club.id_utilisateur = utilisateur.id_utilisateur WHERE id_club= ? ;");
        $req->execute([$club]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_utilisateur]'>$row[email]</option>";
        }
        echo "<option value=1>Invité</option>";
        echo "<option value=2>Aucun</option>";
        ?>
    </select>
    <br><br>
    <label>Id du partenaire 3:</label>
    <select name="id_p3" id="id_p3">
        <?php
        $req = $db->prepare("SELECT membre_club.id_utilisateur , email FROM membre_club INNER JOIN utilisateur ON membre_club.id_utilisateur = utilisateur.id_utilisateur WHERE id_club= ?  ;");
        $req->execute([$club]);
        $results = $req->fetchAll();
        foreach ($results as $row)
        {
            echo "<option value='$row[id_utilisateur]'>$row[email]</option>";
        }
        echo "<option value=1>Invité</option>";
        echo "<option value=2>Aucun</option>";
        ?>
    </select>
    <br><br>
    <input type="submit" value="Réserver le Court">
    <input type="reset" value="Annuler" />
</form>
<br><br>
<!-- Requête pour remplir le tableau des éléments de notre base de données -->
<p style="text-align: center;"> Tout les courts disponibles : </p>
<?php
$query="SELECT * FROM court_de_tennis 
        INNER JOIN emplacement 
        ON emplacement.id_emplacement =court_de_tennis.id_emplacement
        INNER JOIN surface 
        ON surface.id_surface = court_de_tennis.id_surface";
$result=$db->prepare($query);
$result->execute();
?>
<table>
    <thead><tr>
        <th>ID du court</th>
        <th>Nom du terrain</th>
        <th>Club Organisateur</th>
        <th>Emplacement</th>
        <th>Type du surface</th>
    </tr></thead>
    <?php while ($row1 = $result->fetch(PDO::FETCH_ASSOC)) {?>
        <tr>
            <td><?php echo $row1["id_court"];?></td>
            <td><?php echo $row1["nom"];?></td>
            <td><?php echo $row1["club_organisateur"];?></td>
            <td><?php echo $row1["nom_emplacement"];?></td>
            <td><?php echo $row1["nom_surface"];?></td>


        </tr>
    <?php }?>


</table>
    <?php
    $req = $db->prepare("SELECT id_court , nom FROM court_de_tennis WHERE court_de_tennis.statut = 'Disponible';");
    $req->execute([]);
    $results = $req->fetchAll();
    foreach ($results as $court)
    {
    echo "<p style='text-align: center';>$court[nom]</p>";
    ?>



    <br><br>
    <table>
        <thead><tr>
            <th></th>
            <?php
            $date = new DateTime('today');
            $dates = [];
            for ($i = 0; $i < 14; $i++) {
                $dates[] = $date->format('Y-m-d');
                $date->modify('+1 day');
            }


            foreach ($dates as $date_) {
                echo "<th>$date_</th>";
            }
            ?>
        </tr></thead>
        <?php
        //$date = $_POST['datedate'];
        //$day = date('l', strtotime($date));
        $heures = ['08:00', '10:00','12:00','14:00','16:00','18:00'];
        foreach ($heures as $heure) {
            echo "<tr>";
            echo "<th>$heure</th>";
            foreach ($dates as $jour) {
                $db->query("SET lc_time_names = 'fr_FR'");
                $req = $db->prepare( "SELECT * FROM reservation WHERE reservation.`heure debut` ='$heure' AND reservation.date='$jour' AND id_court = ? ;");
                $req->execute([$court["id_court"]]);
                if ($req->rowCount() > 0) {
                            echo "<td style='background-color: #da6262;' >Réservé</td>";
                        } else {
                            echo "<td style='background-color: #78da62;' >Ouvert</td>";
                        }

            }
            echo "</tr>";
        }
        ?>
    </table>

<?php }
    ?>


<br><br>
</body>
</html>