<html>

<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>
<h2>Connexion</h2>
<form method="post" action="../controller/login.php">

    <label>
        *Email : <input type="email" name="Email" required/>
    </label>
    <label>
        *Mot de passe : <input type="password" id="password" name="mdp" required/>
        <button type="button" onclick="togglePasswordVisibility()">Afficher le mot de passe</button>
    </label>
    <script>
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById("password");
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        }
    </script>

    <input type="submit" value="Se connecter" />
</form>
</body>
</html>