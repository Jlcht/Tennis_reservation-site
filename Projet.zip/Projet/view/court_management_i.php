<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>
<h2>Gérer les courts</h2>

<table border="1">
    <tr>
        <th><a href="court_add_i.php">Ajouter un court</a></th>
    </tr>
    <tr>
        <th><a href="court_delete_i.php">Supprimer un court</a></th>
    </tr>
    <tr>
        <th><a href="court_modification_i.php">Modifier un court</a></th>
    </tr>
</table>
<p class="center"><a class="button" href="admin.php">Retour</a></p>

</body>
</html>