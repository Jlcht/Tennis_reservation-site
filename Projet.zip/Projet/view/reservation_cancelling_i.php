<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>

</header>
<nav><a href="admin.php">Retour</a></nav>
<h2>Annuler une reservation</h2>
<form method="POST" action="../controller/reservation_cancelling_c.php">
    <label>Id du court:</label>
    <input type="number" name="id_court" min="1" required>
    <br><br>
    <label>Date</label>
    <input type="date" name="date" min="<?php echo date('Y-m-d'); ?>">
    <br><br>
    <label>Heure</label>
    <select name="time" id="time">
        <option value="08:00:00">08:00</option>
        <option value="10:00">10:00</option>
        <option value="12:00">12:00</option>
        <option value="14:00">14:00</option>
        <option value="16:00">16:00</option>
        <option value="18:00">18:00</option>
    </select>
    <input type="submit" value="Supprimer">
</form>
<p style="text-align: center;"> Tout les courts disponibles : </p>
<?php
$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
$query="SELECT * FROM court_de_tennis 
        INNER JOIN emplacement 
        ON emplacement.id_emplacement =court_de_tennis.id_emplacement
        INNER JOIN surface 
        ON surface.id_surface = court_de_tennis.id_surface";
$result=$db->prepare($query);
$result->execute();
?>
<table>
    <thead><tr>
        <th>ID du court</th>
        <th>Nom du terrain</th>
        <th>Club Organisateur</th>
        <th>Emplacement</th>
        <th>Type du surface</th>
    </tr></thead>
    <?php while ($row1 = $result->fetch(PDO::FETCH_ASSOC)) {?>
        <tr>
            <td><?php echo $row1["id_court"];?></td>
            <td><?php echo $row1["nom"];?></td>
            <td><?php echo $row1["club_organisateur"];?></td>
            <td><?php echo $row1["nom_emplacement"];?></td>
            <td><?php echo $row1["nom_surface"];?></td>
        </tr>
    <?php }?>
</table>
</body>
</html>

