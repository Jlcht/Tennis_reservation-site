<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>
<h2>Ajouter un adhérent</h2>

<form method="post" action="../controller/add_adherant_c.php">
    <p>Veuillez indiquer l'ID de l'adhérant à ajouter </p>
    <label>
        ID : <input type="number" name="id" />
    </label>
    <br />
    <input type="submit" value="Ajouter">
</form>
<p class = "center"><a class ="button" href="admin.php">Retour</a></p>
</body>
</html>
