<html>
<head>
    <title>Book-Tenis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-tennis</h1>
</header>
<h2>Changer son mot de passe</h2>
<form method="post" action="../controller/change_password.php">

    <label>
        Mot de passe actuel : <input type="password" name="mdp_actuel" required/>
    </label>
    <label>
        Nouveau Mot de passe : <input type="password" name="nv_mdp" required/>
    </label>
    <label>
        Confirmation Mot de passe : <input type="password" name="conf_nv_mdp" required/>
    </label>

    <input type="submit" value="Changer le mot de passe" />
</form>

</body>
</html>