<?php
session_start();
$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
$id_club = $_SESSION["club"];

$req1 = $db->prepare("SELECT COUNT(membre_club.id_utilisateur) AS member_count FROM membre_club WHERE membre_club.id_club = ?");

$req1->execute([$id_club]);
$count = $req1->fetchColumn();
echo "Nombre de membres dans le club : " . $count;

/*
$req2 = $db->prepare("SELECT 
  u.id_utilisateur, 
  u.nom, 
  u.prenom, 
  SUM(TIME_TO_SEC(r.duree) * 60) AS total_hours
FROM 
  utilisateur u
  JOIN reservation r ON u.id_utilisateur = r.id_organisateur
WHERE 
  YEAR(r.`heure debut`) = YEAR(CURRENT_DATE())
GROUP BY 
  u.id_utilisateur, 
  u.nom, 
  u.prenom;");

$req2->execute();

$req3 = $db->prepare("SELECT 
  c.id_court, 
  c.nom, 
  WEEKOFYEAR(r.heure_debut) AS semaine,
  AVG(r.duree / (60 * 24 * 7)) AS taux_reservation_moyen
FROM 
  court_de_tennis c
  JOIN reservation r ON c.id_court = r.id_court
WHERE 
  YEAR(r.heure_debut) = YEAR(CURRENT_DATE())
GROUP BY 
  c.id_court, 
  c.nom, 
  semaine;");

$req3->execute();
*/
?>