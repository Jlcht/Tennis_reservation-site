<html>
<head>
    <title>Book-Tennis</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<header>
    <img src="logo.png" alt="Logo Book-Tenis" />
    <h1>Book-Tenis</h1>
</header>
<h2>Inscription</h2>
<form method="post" action="../controller/signup.php">

    <label>
        *Nom : <input type="text" name="Nom" required/>
    </label>
    <label>
        *Prénom : <input type="text" name="Prenom" required/>
    </label>

    <label>
        *Email : <input type="email" name="Email" required/>
    </label>
    <label>
        *Mot de passe : <input type="password" name="mdp" required/>
    </label>

    <br>

    <input type="submit" value="S'inscrire" />
    <input type="reset" value="Annuler" />
</form>

</body>
</html>