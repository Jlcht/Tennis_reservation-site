<?php

$court = $_POST["court"];

$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$req = $db->prepare("DELETE FROM court_de_tennis WHERE id_court = ?");

$req->execute([$court]);

header("Location: ../view/admin.php");