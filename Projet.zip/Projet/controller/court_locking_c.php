<?php

$statut = $_POST["statut"];
$court = $_POST["court"];

$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$req = $db->prepare("UPDATE court_de_tennis SET court_de_tennis.statut = ? WHERE id_court = ?");

$req->execute([$statut,$court]);

header("Location: ../view/admin.php");