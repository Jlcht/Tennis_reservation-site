<?php
$court = $_POST["id_court"];
$date = $_POST["date"];
$time = $_POST["time"];


$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$req = $db->prepare("DELETE FROM reservation WHERE `id_court` = ? AND `date` = ? AND `heure debut` = ? ;");

$req->execute([$court , $date , $time]);

header("Location: ../view/admin.php");
?>