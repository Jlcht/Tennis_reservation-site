<?php

session_start();
$id_club = $_SESSION["club"];
$id_user = $_POST["id"];

$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$req = $db->prepare("DELETE FROM membre_club WHERE id_utilisateur = ? AND id_club = ? ");

$req->execute([$id_user,$id_club]);

header("Location: ../view/admin.php");