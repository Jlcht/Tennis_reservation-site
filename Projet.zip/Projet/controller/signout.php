<html>
<head>
    <title>login</title>
</head>
<body>
<?php
session_destroy();
header("Location: ../view/login.php");
?>
</body>
</html>
