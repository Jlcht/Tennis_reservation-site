<html>
<link rel="stylesheet" type="text/css" href="style.css">
<body>
<?php

$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");


$idcourt=$_POST["id_court"];
$date =$_POST["date"];
$heure=$_POST["time"];
$idp1=$_POST["id_p1"];
$idp2=$_POST["id_p2"];
$idp3=$_POST["id_p3"];
$duree=$_POST["duree"];
session_start();
$email=$_SESSION["Email"];
$club = $_SESSION["club"];
//Récuperer l'id de l'utilisateur;
$rid_utilisateur=$db->prepare("SELECT id_utilisateur FROM utilisateur WHERE email=?");
$rid_utilisateur->execute([$email]);
$id_utilisateur=$rid_utilisateur->fetchColumn();

//regarder si la réservation existe deja
$rcheckterrain = $db->prepare("SELECT * FROM reservation WHERE duree = ? AND `heure debut` = ?");
$rcheckterrain->execute([$duree,$heure]);

//Mettre dans la table reservation
if ($rcheckterrain->rowCount() > 0) {
    $terrain_pas_dispo = "Ce terrain est deja utilisé à cette date et horaire. Veuillez en utiliser un autre.";
}
else {
    // Insertion de de la réservation dans la table "reservation"
    $r_reservation = $db->prepare("INSERT INTO reservation (duree,`heure debut`,partenaire_1,partenaire_2,partenaire_3,club_organisateur,id_court , date) VALUES (?,?, ?, ?, ?, ?, ? ,?)");
    $r_reservation->execute([$duree,$heure, $idp1, $idp2, $idp3,$club, $idcourt , $date]);
    $samarche="Votre réservation a bien été pris en compte";
}
?>
<?php if (isset($terrain_pas_dispo)): ?>
<div class="error-box">
    <h3><?php echo $terrain_pas_dispo; ?></h3>
    <nav><a href="../view/reservation_court.php">Réservé un autre court</a></nav>
</div>
<?php endif; ?>
<?php if (isset($samarche)): ?>
    <div class="error-box">
        <h3><?php echo $samarche; ?></h3>
        <p><a href="../view/account.php">Revenir à l'accueil</a></p>
        <p><a href="../view/reservation_court.php">Réserver un autre court</a></p>
    </div>
<?php endif; ?>
</body>
</html>