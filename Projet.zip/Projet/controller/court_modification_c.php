<?php


$court = $_POST["court"];
$name = $_POST["name"];
$surface = $_POST["surface"];
$emplacement = $_POST["emplacement"];


$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$req = $db->prepare("UPDATE court_de_tennis SET nom = ?, id_surface = ?, id_emplacement = ? WHERE id_court = ?");

$req->execute([$name, $surface, $emplacement, $court]);

header("Location: ../view/admin.php");