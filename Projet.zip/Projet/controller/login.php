<html>
<head>
    <title>login</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<?php
$bdd = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$email = $_POST["Email"];
$mdp =$_POST["mdp"];

$req = $bdd->prepare("SELECT email, mdp FROM utilisateur WHERE email = ?");
// Exécution de la requête
$req->execute([$email]);

//Récupération de l'éventuel résultat
$data = $req->fetch();
//Vérification du password
if($data != null && password_verify($mdp, $data['mdp']))
{
    session_start();
    $_SESSION["Email"] = $email;
    header("Location:../view/account.php");
}
else
{
    $login_error = "Email ou mot de passe incorrect.";
}
?>

<?php if (isset($login_error)): ?>
    <div class="error-box">
        <p><?php echo $login_error; ?></p>
        <a href="../view/login.php">Réessayer</a>
    </div>
<?php endif; ?>

</body>
</html>