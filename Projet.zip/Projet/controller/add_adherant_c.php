<?php
session_start();
$club = $_SESSION["club"] ;
$id_user = $_POST["id"];

$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$req = $db->prepare("INSERT INTO membre_club (id_utilisateur , id_club , statut) VALUES (?,? ,0) ");

$req->execute([$id_user,$club]);

header("Location: ../view/admin.php");