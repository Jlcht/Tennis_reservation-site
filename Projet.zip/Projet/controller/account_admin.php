<?php

session_start();
$club = $_POST["club"];
$_SESSION["club"] = $club;

header("Location:../view/admin.php");

?>
