<?php
session_start();
$id_club = $_SESSION['club'];
$name = $_POST["name"];
$surface = $_POST["surface"];
$emplacement = $_POST["emplacement"];

$db = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$req = $db->prepare("INSERT INTO court_de_tennis (nom, id_surface, id_emplacement , club_organisateur , statut) VALUES (?, ?,? , ? , ?)");

$req->execute([$name, $surface  ,$emplacement , $id_club , "Disponible"]);

header("Location: ../view/admin.php");
?>