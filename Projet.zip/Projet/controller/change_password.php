<html>
<head>
    <title>login</title>
    <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
<?php
session_start();

if(isset($_SESSION["Email"])) {
    $email = $_SESSION["Email"];
    $bdd = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");
    $ancien_mdp =$_POST["mdp_actuel"];
    $nv_mdp = $_POST["nv_mdp"];
    $conf_nv_mdp = $_POST["conf_nv_mdp"];
    $req = $bdd->prepare("SELECT mdp FROM utilisateur WHERE email = ?");
    // Exécution de la requête
    $req->execute([$email]);
    //Récupération de l'éventuel résultat
    $data = $req->fetch();

    if ($nv_mdp != $conf_nv_mdp) {
        $error = "Les nouveaux mots de passe ne correspondent pas.";

    }

    //Vérification du password
    if(password_verify($ancien_mdp, $data['mdp']) && $nv_mdp==$conf_nv_mdp)
    {
        $req_mdp = $bdd->prepare("UPDATE `utilisateur` SET `mdp` = ? WHERE email = ?");
        $req_mdp->execute([password_hash($nv_mdp, PASSWORD_DEFAULT),$email]);
        $success = "Votre mot de passe a été modifié avec succès.";
    }
    else
    {
        $error = "Le mot de passe actuel est incorrect.";
    }
}
?>

<?php if (isset($error)): ?>
    <div class="error-box">
        <p><?php echo $error; ?></p>
        <a href="../view/change_password.php">Réessayer</a>
    </div>
<?php endif; ?>

<?php if (isset($success)): ?>
    <div class="success-box">
        <p><?php echo $success; ?></p>
        <a href="../view/login.php">Se connecter</a>
    </div>
<?php endif; ?>
</body>
</html>
