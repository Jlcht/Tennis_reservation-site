<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>signup</title>
</head>
<body>
<?php
$bdd = new PDO("mysql:host=localhost;dbname=reservation_tennis;charset=utf8", "root", "");

$nom = $_POST["Nom"];
$prenom = $_POST["Prenom"];
$email = $_POST["Email"];
$mdp = $_POST["mdp"];

// Check if email already exists
$req_check_email = $bdd->prepare("SELECT * FROM utilisateur WHERE email = ?");
$req_check_email->execute([$email]);
$existing_email = $req_check_email->fetch();

if ($existing_email) {
    $email_error = "Cet email est déjà utilisé. Veuillez en utiliser un autre.";
} else {
    // Insertion de l'utilisateur dans la table "utilisateur"
    $req_utilisateur = $bdd->prepare("INSERT INTO utilisateur (nom, prenom, mdp, email) VALUES (?, ?, ?, ?)");
    $req_utilisateur->execute([$nom, $prenom, password_hash($mdp, PASSWORD_DEFAULT), $email]);

    header("Location: ../view/login.php");
}
?>

<?php if (isset($email_error)): ?>
    <div class="error-box">
        <p><?php echo $email_error; ?></p>
        <a href="../view/signup.php">S'inscrire</a>
    </div>
<?php endif; ?>
</body>
</html>